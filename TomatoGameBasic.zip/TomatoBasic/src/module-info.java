/**
 * 
 */
/**
 * 
 */
module TomatoBasic {
	requires java.desktop;
}