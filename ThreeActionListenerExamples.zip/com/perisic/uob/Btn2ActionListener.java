package com.perisic.uob;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class Btn2ActionListener implements ActionListener {
	
	public void actionPerformed(ActionEvent evt) { 
		JOptionPane.showMessageDialog(null, "Button TWO has been pressed.");
	}

}
