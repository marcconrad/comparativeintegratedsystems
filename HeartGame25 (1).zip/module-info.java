/**
 * 
 */
/**
 * 
 */
module TomatoGame {
	requires java.desktop;
}